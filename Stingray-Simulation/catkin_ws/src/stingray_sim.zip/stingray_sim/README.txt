First, source:

-source /opt/ros/melodic/setup.bash
-source ~/Stingray-Simulation/catkin_ws/devel/setup.bash
-source ~/Stingray-Simulation/stingray_setup.bash

To run launch file:

-roslaunch stingray_sim wall_following_v1.launch

Additionally, you can rosrun my source file:

-Navigate to stingray_sim's src folder if you didn't source, then:
	-rosrun stingray_sim wall_follow.py
