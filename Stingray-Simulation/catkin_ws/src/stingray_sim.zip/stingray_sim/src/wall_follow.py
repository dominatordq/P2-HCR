#!/usr/bin/env python

"""
Dominic Quintana
Wall_follow source file
"""

import rospy
from itertools import product
from geometry_msgs.msg import Pose2D
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String
"""
Class for wall following robot
"""
class WallFollower:
    """
    initialize variables, etc.
    """
    def __init__(self):
        rospy.init_node('follower', anonymous=True)
        self.subscriber = rospy.Subscriber('/scan', LaserScan, self.get_distance)
        self.publisher = rospy.Publisher('/triton_lidar/vel_cmd', Pose2D, queue_size=10)
 
        self.st = (2, 2, 2)
        self.current = [2, 2, 2]
        self.poses = {0: (0, 2, 4), 1: (0, 2, 0), 2: (0, 2, -4)}
        self.thresholds = {0: [0.4, 1.0], 1: [0.4, 1.4], 2: [0.25, 0.4]} 

        self.rate = rospy.Rate(10) 
        # set up Q-table variables - [(left or near), (forward or middle), (right or far)]
        actions = [0, 1, 2]     
        substate = [0, 1, 2]    
        state = [sta for sta in product(substate, substate, substate)] 
        cont = 1    # continue
        move_toward = 2
        away = 3 
        turn = 4
        
        self.q = {(sta, act): 0 for act in actions for sta in state} # Q-table
        for tup in self.q.keys():
            if tup[1] == 0 and tup[0][2] == 0:
                self.q[tup] = away
            if tup[1] == 2 and tup[0][0] == 0:
                self.q[tup] = away
            if tup[1] == 1 and tup[0][2] == 1:
                self.q[tup] = cont
            if tup[1] == 2 and tup[0][2] == 2: 
                self.q[tup] = move_toward
            if tup[0][0] == 2 and tup[0][1] == 2 and tup[0][2] == 2:
                self.q[tup] = cont
            if tup[1] == 0 and tup[0][1] < 2:
                self.q[tup] = turn
    
    def get_distance(self, var):
        l = var.ranges[179] # get left distance
        r = var.ranges[0]   # get right distance 
        f = var.ranges[89]  # get front distance
        self.current = [2, 2, 2]
        distances = [l, f, r]
        for i, dist in enumerate(distances):
            for j in range(len(self.thresholds[0])):
                if dist <= self.thresholds[i][j]:
                    self.current[i] = j
                    break
        self.st = tuple(self.current)

    def wall_follow(self):
        while not rospy.is_shutdown():
            nextAction = 1
            max_num = 0
            for tup in self.q.keys():
                if tup[0] == self.st and self.q[tup] > max_num:
                    nextAction = tup[1]
                    max_num = self.q[tup]

            print "making a move", nextAction
            pose = Pose2D()
            pose.x, pose.y, pose.theta = self.poses[nextAction]
            self.publisher.publish(pose)
            self.rate.sleep()

if __name__ == '__main__':
    wall_follower = WallFollower()
    wall_follower.wall_follow()
